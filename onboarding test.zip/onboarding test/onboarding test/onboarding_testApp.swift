//
//  onboarding_testApp.swift
//  onboarding test
//
//  Created by Christopher on 2022/07/04.
//

import SwiftUI

@main
struct onboarding_testApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
